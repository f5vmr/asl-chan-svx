# chan_svx

An Asterisk **channel driver for AllStarLink 3 (app_rpt)** that speaks the
SvxLink **SVXReflector** protocol directly.

It lets an AllStar node connect straight to a SVXReflector — removing the
`chan_usrp` ↔ svxlink hop and the extra vocoder tandem that comes with it.
Audio is carried as **Opus** with a single transcode; on a node the path is
just PCM ↔ Opus (no resampling, 8 kHz / 20 ms frames).

```
   Before:  app_rpt --USRP--> svxlink --Opus--> SVXReflector
   With chan_svx:  app_rpt --------Opus--------> SVXReflector
```

- One channel instance = **one reflector login = one talkgroup = one stream**.
- slin 8 kHz ↔ Opus, inband **FEC** on by default.
- TX keys the reflector talker (`RADIO_KEY` → TalkerStart) with a configurable
  **TalkerStop hold time** (`tx_hold`), so a brief unkey/rekey mid-over (COS
  flicker, link hangtime) does not chop the stream at the reflector.
- **RX robustness for real-world links:** configurable jitter buffer, Opus
  inband-FEC recovery of lost packets, and PLC concealment on underrun.
- **Audio conditioning** per direction: preamp gain, optional AGC, and a
  clipping limiter (`rx_gain`/`tx_gain`, `rx_agc`/`tx_agc`).
- Auto-reconnect with backoff; TCP + UDP heartbeats; HMAC-SHA1 auth.

## Supported platforms

64-bit only: **Raspberry Pi 3 / 4 / 5** (arm64) and **x86-64**, running
**AllStarLink 3** (Debian 12/13, `asl3-asterisk`). Not built for armhf; the
Pi Zero 2 W is intentionally unsupported (heat + Wi-Fi).

## Requirements

Built and loaded against the exact `asl3-asterisk` on the box (ABI-matched).
Runtime dependencies (pulled in automatically by the `.deb`):

- `asl3-asterisk`
- `libopus0`
- `libssl3` (OpenSSL, for HMAC-SHA1)

## Install

See **[INSTALL.md](INSTALL.md)** for the full walkthrough. Short version:

```sh
sudo apt install ./asl3-chan-svx_*.deb          # or from the apt repo
sudoedit /etc/asterisk/svx.conf                 # from svx.conf.sample
# add 'rxchannel = SVX/<section>' to your node in rpt.conf
# enable the (commented) load line in modules.conf
sudo asterisk -rx "core restart now"
sudo asterisk -rx "svx show"                     # should say CONNECTED
```

## Configuration

- `/etc/asterisk/svx.conf` — one `[section]` per reflector connection. See
  [`examples/svx.conf.sample`](examples/svx.conf.sample).
- `rxchannel = SVX/<section>` in the node's `rpt.conf` stanza. See
  [`examples/rpt.conf.snippet`](examples/rpt.conf.snippet).

## CLI

```
svx show      — connection state + TX/RX frame counters per instance
```

## Building from source

The reflector wire path is provable without Asterisk:

```sh
make            # builds the standalone self-test binary 'svxtest'
./svxtest       # offline protocol + codec self-tests
./svxtest <host> <port> <login> <password> <tg> <callsign> [seconds] [rx|tx]
```

The Asterisk module is built against installed `asl3-asterisk-dev` headers:

```sh
sudo apt install asl3-asterisk-dev libopus-dev libssl-dev
make -f Makefile.module
sudo make -f Makefile.module install
```

Or build the Debian package: `dpkg-buildpackage -b -uc -us`.

## Bug reports

Open an issue on the source repo, or email **bjorne@sa7aux.se**. Please include
your platform (Pi/x86, OS), `asterisk -V`, and the output of `svx show`.

## Author & License

Copyright © 2026 **SA7AUX** &lt;bjorne@sa7aux.se&gt;.

GNU GPL v2 — same as Asterisk and app_rpt. See [debian/copyright](debian/copyright).
