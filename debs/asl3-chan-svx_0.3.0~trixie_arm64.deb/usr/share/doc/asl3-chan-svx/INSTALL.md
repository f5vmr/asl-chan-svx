# Installing and setting up chan_svx

chan_svx connects an AllStarLink 3 node straight to a SVXReflector. After
installing the package you do three small things: create a config, point a
node at it, and enable the module. Nothing loads or connects behind your back.

## 1. Install the package

```sh
sudo apt install ./asl3-chan-svx_<version>_<arch>.deb
```

`<arch>` is `arm64` (Raspberry Pi 3/4/5) or `amd64` (x86-64). Dependencies
(`asl3-asterisk`, `libopus0`, `libssl3`) are pulled in automatically.

The package installs:

- the module `chan_svx.so` into the Asterisk module directory,
- `/etc/asterisk/svx.conf.sample` (example config),
- this documentation.

It also appends a **commented** load line to `/etc/asterisk/modules.conf` —
you enable it yourself in step 3.

## 2. Create your reflector config

Copy the sample and edit it:

```sh
sudo cp /etc/asterisk/svx.conf.sample /etc/asterisk/svx.conf
sudo chown asterisk:asterisk /etc/asterisk/svx.conf
sudo chmod 640 /etc/asterisk/svx.conf
sudoedit /etc/asterisk/svx.conf
```

Each `[section]` is one reflector connection = one login = one talkgroup:

```ini
[1999]
host     = reflector.example.org
port     = 5300
login    = MYCALL-N        ; your OWN login, not shared with any other client
password = your-auth-key
callsign = MYCALL
tg       = 24016
; monitor = 24020, 9990    ; optional extra RX-only talkgroups
; bitrate = 16000          ; optional, default 16000
```

> **Important:** the reflector needs a dedicated login for this node. Do not
> reuse a login that another client (e.g. an existing svxlink) already uses —
> the reflector will kick one of them off.

## 3. Enable the module

`modules.conf` on AllStar has `autoload = no`, so chan_svx must be listed
explicitly. The package added this line, commented, near the other channel
drivers — uncomment it:

```ini
; --- chan_svx (added by asl3-chan-svx; uncomment to enable) ---
load = chan_svx.so
```

(Do it by hand, or: `sudo sed -i 's/^; *load = chan_svx.so/load = chan_svx.so/' /etc/asterisk/modules.conf`.)

It must load **before** app_rpt brings up the node, which it does — channel
drivers load ahead of applications.

## 4. Point a node at it

In `/etc/asterisk/rpt.conf`, set the node's `rxchannel` to `SVX/<section>`.
**Comment out the old rxchannel, don't delete it** — so you can revert:

```ini
[1999](node-main)
; rxchannel = USRP/127.0.0.1:4001:4002   ; old bridge, kept for reference
rxchannel = SVX/1999                     ; chan_svx -> section [1999] in svx.conf
```

See [`examples/rpt.conf.snippet`](examples/rpt.conf.snippet).

## 5. Apply and verify

An `rxchannel` change needs app_rpt to re-init, so restart Asterisk:

```sh
sudo asterisk -rx "core restart now"
```

Then check:

```sh
sudo asterisk -rx "svx show"
```

You should see the connection up:

```
SVX/1999: reflector.example.org:5300 TG 24016 login 'MYCALL-N' — CONNECTED, tx idle
    txframes=0 txbadsize=0(last datalen=0) rxframes=0
```

Key up on the node → `txframes` climbs and the reflector opens the talker on
your TG. When someone else talks on the TG → `rxframes` climbs. The reflector
side logs `Talker start/stop on TG #<tg>` for your login.

## Troubleshooting

| Symptom | Check |
|---|---|
| `svx show` empty / node has no rxchannel | Is `load = chan_svx.so` enabled in modules.conf? Did you `core restart now`? |
| `down` instead of `CONNECTED` | host/port reachable? login/password correct? Reflector logs `auth`? |
| `txframes` climbs but nobody hears you | Is the *listening* client actually selecting/monitoring the same TG? |
| `txbadsize` climbing | app_rpt is feeding non-slin frames — check the node's audio format. |
| Loads but refuses (`compile-time options`) | The package must match the installed `asl3-asterisk` version — reinstall/rebuild against it. |

## Reverting

Comment `rxchannel = SVX/1999` (restore the old line), comment `load = chan_svx.so`
in modules.conf, `core restart now`. To remove entirely: `sudo apt remove asl3-chan-svx`.
